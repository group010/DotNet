﻿using System;

namespace Assignment_02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Infoway");
            Console.ReadKey();
        }
    }
}
